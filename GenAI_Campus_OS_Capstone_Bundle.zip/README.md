# README for GenAI Campus OS
